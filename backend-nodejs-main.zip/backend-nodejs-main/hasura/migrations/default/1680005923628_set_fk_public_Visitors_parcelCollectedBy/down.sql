alter table "public"."Visitors" drop constraint "Visitors_parcelCollectedBy_fkey";
