DROP TABLE "public"."LocalServiceProviderAndRentalUnits";
