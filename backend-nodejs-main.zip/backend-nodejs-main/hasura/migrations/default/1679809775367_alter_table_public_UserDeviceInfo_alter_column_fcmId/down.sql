alter table "public"."UserDeviceInfo" alter column "fcmId" set not null;
