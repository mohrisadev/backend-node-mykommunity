alter table "public"."UserDeviceInfo" alter column "fcmId" drop not null;
