alter table "public"."LocalServiceProviders" add column "isInside" boolean
 not null default 'false';
