DROP TABLE "public"."Notices";
