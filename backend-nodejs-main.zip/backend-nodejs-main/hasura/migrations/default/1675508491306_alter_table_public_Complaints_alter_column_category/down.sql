alter table "public"."Complaints" rename column "categoryId" to "category";
