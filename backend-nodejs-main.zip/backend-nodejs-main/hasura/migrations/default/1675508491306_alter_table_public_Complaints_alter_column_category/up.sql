alter table "public"."Complaints" rename column "category" to "categoryId";
