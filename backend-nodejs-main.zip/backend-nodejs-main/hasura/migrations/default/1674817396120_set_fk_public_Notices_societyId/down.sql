alter table "public"."Notices" drop constraint "Notices_societyId_fkey";
