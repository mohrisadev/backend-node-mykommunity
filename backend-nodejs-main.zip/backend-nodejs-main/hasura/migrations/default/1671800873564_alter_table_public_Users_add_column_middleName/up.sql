alter table "public"."Users" add column "middleName" text
 null;
