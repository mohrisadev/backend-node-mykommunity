DROP TABLE "public"."GroupDiscussionComments";
