DROP TABLE "public"."Cities";
