alter table "public"."Visitors" add column "leaveParcelAtGate" boolean
 not null default 'false';
