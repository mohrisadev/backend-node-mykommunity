alter table "public"."UserRoles" drop constraint "UserRoles_societyId_fkey";
