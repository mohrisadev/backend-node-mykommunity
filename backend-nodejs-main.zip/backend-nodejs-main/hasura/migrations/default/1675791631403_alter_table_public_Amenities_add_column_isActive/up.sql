alter table "public"."Amenities" add column "isActive" boolean
 not null default 'true';
