CREATE  INDEX "Complaints_societyId" on
  "public"."Complaints" using btree ("societyId");
