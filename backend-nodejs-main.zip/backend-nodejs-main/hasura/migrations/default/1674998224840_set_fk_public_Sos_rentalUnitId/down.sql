alter table "public"."Sos" drop constraint "Sos_rentalUnitId_fkey";
