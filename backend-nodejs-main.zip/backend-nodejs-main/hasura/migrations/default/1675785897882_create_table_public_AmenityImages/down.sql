DROP TABLE "public"."AmenityImages";
