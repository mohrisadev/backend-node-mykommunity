alter table "public"."BookedAmenity" add column "slotsBooked" integer
 not null;
