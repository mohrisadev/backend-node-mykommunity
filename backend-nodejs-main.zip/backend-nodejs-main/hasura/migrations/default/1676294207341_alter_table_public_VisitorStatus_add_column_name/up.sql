alter table "public"."VisitorStatus" add column "name" text
 not null;
