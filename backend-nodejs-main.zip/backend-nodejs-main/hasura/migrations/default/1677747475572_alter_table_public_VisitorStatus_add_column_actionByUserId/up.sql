alter table "public"."VisitorStatus" add column "actionByUserId" uuid
 null;
