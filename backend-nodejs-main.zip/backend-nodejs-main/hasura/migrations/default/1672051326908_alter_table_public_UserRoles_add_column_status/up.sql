alter table "public"."UserRoles" add column "status" text
 null;
