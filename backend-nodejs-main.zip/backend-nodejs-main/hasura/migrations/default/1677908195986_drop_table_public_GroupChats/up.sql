DROP table "public"."GroupChats";
