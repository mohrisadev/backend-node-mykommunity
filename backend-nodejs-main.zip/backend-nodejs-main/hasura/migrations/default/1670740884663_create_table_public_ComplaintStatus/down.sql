DROP TABLE "public"."ComplaintStatus";
