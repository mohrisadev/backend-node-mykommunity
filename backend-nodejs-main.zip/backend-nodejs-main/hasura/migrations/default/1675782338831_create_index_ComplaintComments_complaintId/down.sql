DROP INDEX IF EXISTS "public"."ComplaintComments_complaintId";
