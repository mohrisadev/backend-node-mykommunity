CREATE  INDEX "ComplaintComments_complaintId" on
  "public"."ComplaintComments" using btree ("complaintId");
