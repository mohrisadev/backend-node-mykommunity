alter table "public"."Amenities" add column "maxCapacity" integer
 null;
