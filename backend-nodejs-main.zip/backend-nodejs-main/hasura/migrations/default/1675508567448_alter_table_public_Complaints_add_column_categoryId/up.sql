alter table "public"."Complaints" add column "categoryId" uuid
 not null;
