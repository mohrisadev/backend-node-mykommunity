DROP TABLE "public"."LocalServiceProviders";
