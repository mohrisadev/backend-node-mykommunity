DROP TABLE "public"."Blocks";
