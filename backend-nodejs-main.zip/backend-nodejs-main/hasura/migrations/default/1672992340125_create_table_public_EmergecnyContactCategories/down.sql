DROP TABLE "public"."EmergecnyContactCategories";
