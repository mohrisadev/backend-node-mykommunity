DROP INDEX IF EXISTS "public"."LocalServiceProviderAttendance_createdAt";
