CREATE  INDEX "LocalServiceProviderAttendance_createdAt" on
  "public"."LocalServiceProviderAttendance" using btree ("createdAt");
