alter table "public"."BookedAmenityStatus" rename to "AmenityStatus";
