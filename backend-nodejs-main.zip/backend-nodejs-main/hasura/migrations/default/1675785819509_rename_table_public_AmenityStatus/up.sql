alter table "public"."AmenityStatus" rename to "BookedAmenityStatus";
