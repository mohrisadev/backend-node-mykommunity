DROP TABLE "public"."ComplaintComments";
