alter table "public"."GroupDiscussion" drop constraint "GroupDiscussion_userId_fkey";
