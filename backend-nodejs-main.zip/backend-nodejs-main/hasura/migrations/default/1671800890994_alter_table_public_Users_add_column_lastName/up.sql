alter table "public"."Users" add column "lastName" text
 null;
