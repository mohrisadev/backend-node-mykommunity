DROP INDEX IF EXISTS "public"."UserRoles_societyId";
