CREATE  INDEX "ComplaintComments_userId" on
  "public"."ComplaintComments" using btree ("userId");
