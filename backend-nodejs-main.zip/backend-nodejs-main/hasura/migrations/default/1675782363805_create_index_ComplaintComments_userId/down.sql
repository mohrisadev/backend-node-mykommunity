DROP INDEX IF EXISTS "public"."ComplaintComments_userId";
