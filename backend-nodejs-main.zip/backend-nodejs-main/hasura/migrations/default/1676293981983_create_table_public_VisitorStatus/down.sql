DROP TABLE "public"."VisitorStatus";
