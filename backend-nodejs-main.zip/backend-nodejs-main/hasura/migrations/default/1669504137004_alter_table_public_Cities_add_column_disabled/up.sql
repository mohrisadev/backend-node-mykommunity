alter table "public"."Cities" add column "disabled" boolean
 not null default 'false';
