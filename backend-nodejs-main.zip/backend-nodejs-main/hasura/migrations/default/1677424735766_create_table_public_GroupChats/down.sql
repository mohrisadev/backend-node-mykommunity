DROP TABLE "public"."GroupChats";
