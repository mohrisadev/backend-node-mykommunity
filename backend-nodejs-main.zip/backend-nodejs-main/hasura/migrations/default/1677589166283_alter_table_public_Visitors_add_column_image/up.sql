alter table "public"."Visitors" add column "image" text
 null;
