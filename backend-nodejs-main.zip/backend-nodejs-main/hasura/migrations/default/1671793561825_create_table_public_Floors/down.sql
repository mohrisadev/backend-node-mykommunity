DROP TABLE "public"."Floors";
