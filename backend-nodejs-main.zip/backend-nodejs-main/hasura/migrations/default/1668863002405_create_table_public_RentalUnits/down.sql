DROP TABLE "public"."RentalUnits";
