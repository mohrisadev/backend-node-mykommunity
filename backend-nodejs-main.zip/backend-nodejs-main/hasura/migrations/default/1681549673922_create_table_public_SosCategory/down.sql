DROP TABLE "public"."SosCategory";
