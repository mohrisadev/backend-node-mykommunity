alter table "public"."Users" add column "name" text
 null;
