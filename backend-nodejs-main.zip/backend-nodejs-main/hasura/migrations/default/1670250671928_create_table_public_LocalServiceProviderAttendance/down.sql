DROP TABLE "public"."LocalServiceProviderAttendance";
