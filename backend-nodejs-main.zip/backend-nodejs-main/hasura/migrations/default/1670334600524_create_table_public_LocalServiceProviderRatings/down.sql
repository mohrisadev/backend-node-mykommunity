DROP TABLE "public"."LocalServiceProviderRatings";
