alter table "public"."Amenities" add column "advanceBookingLimitInDays" integer
 null;
