CREATE  INDEX "UserRoles_roles" on
  "public"."UserRoles" using hash ("role");
