alter table "public"."GroupDiscussionComments" add column "photoUrl" text
 null;
