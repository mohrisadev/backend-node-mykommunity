alter table "public"."Sos" add column "rentalUnitId" uuid
 not null;
