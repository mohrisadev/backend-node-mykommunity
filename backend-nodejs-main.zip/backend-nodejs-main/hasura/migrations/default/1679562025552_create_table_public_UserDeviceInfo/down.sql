DROP TABLE "public"."UserDeviceInfo";
