alter table "public"."GroupDiscussion"
  add constraint "GroupDiscussion_societyId_fkey"
  foreign key ("societyId")
  references "public"."Societies"
  ("id") on update restrict on delete restrict;
