alter table "public"."GroupDiscussion" drop constraint "GroupDiscussion_societyId_fkey";
