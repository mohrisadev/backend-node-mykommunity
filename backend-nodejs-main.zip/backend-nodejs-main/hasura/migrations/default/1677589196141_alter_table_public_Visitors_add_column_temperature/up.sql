alter table "public"."Visitors" add column "temperature" numeric
 null;
