CREATE  INDEX "RentalUnits_floorId" on
  "public"."RentalUnits" using btree ("floorId");
