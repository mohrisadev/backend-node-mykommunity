alter table "public"."Users" add column "disabled" boolean
 not null default 'false';
