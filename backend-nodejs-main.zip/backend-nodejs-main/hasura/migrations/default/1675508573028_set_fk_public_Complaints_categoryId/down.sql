alter table "public"."Complaints" drop constraint "Complaints_categoryId_fkey";
