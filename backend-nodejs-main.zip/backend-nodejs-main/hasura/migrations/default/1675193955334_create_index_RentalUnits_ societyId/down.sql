DROP INDEX IF EXISTS "public"."RentalUnits_ societyId";
