CREATE  INDEX "RentalUnits_ societyId" on
  "public"."RentalUnits" using btree ("societyId");
