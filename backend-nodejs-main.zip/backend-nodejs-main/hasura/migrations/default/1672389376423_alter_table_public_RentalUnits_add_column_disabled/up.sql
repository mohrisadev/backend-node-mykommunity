alter table "public"."RentalUnits" add column "disabled" boolean
 not null default 'false';
