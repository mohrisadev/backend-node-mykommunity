alter table "public"."Sos" add column "acknowledgedAt" timestamptz
 null;
