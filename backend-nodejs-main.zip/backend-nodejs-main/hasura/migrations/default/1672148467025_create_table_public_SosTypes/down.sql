DROP TABLE "public"."SosTypes";
