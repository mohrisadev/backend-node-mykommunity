CREATE  INDEX "LocalServiceProviderAndRentalUnits_rentalUnitId" on
  "public"."LocalServiceProviderAndRentalUnits" using btree ("rentalUnitId");
