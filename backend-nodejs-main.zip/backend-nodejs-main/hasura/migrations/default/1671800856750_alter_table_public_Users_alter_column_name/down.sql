alter table "public"."Users" rename column "firstName" to "name";
