alter table "public"."Users" rename column "name" to "firstName";
