alter table "public"."ComplaintComments" add column "photoUrl" text
 null;
