alter table "public"."Users" add column "mobileNumber" Text
 not null;
