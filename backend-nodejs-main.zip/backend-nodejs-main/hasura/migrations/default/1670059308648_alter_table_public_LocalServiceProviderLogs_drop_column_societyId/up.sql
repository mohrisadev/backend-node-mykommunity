alter table "public"."LocalServiceProviderLogs" drop column "societyId" cascade;
