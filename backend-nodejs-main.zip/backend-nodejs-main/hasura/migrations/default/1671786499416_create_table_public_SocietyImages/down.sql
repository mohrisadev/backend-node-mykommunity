DROP TABLE "public"."SocietyImages";
