alter table "public"."LocalServiceProviders" add column "localServiceProviderCode" text
 null;
