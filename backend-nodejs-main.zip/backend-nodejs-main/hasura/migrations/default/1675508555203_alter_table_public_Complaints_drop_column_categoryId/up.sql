alter table "public"."Complaints" drop column "categoryId" cascade;
