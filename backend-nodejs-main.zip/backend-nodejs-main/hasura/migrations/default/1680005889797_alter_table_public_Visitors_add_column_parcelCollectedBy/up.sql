alter table "public"."Visitors" add column "parcelCollectedBy" uuid
 null;
