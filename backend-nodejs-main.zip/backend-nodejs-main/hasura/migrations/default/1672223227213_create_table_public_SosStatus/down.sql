DROP TABLE "public"."SosStatus";
