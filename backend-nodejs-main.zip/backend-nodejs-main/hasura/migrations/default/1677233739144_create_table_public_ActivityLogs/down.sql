DROP TABLE "public"."ActivityLogs";
