DROP TABLE "public"."Amenities";
