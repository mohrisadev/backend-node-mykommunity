alter table "public"."VisitorStatus" drop constraint "VisitorStatus_actionByUserId_fkey";
