DROP TABLE "public"."Sos";
