DROP TABLE "public"."Societies";
