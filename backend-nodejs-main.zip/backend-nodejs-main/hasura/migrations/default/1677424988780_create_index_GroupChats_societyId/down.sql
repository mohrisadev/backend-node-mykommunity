DROP INDEX IF EXISTS "public"."GroupChats_societyId";
