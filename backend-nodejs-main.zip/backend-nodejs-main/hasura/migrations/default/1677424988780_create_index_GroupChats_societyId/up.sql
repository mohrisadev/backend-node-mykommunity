CREATE  INDEX "GroupChats_societyId" on
  "public"."GroupChats" using btree ("societyId");
