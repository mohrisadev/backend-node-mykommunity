alter table "public"."EmergecnyContactCategories" rename to "EmergencyContactCategories";
