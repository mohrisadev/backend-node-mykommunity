alter table "public"."EmergencyContactCategories" rename to "EmergecnyContactCategories";
