alter table "public"."RentalUnits" add column "floorId" uuid
 not null;
