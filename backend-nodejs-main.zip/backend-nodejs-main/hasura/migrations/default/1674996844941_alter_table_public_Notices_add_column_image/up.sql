alter table "public"."Notices" add column "image" text
 null;
