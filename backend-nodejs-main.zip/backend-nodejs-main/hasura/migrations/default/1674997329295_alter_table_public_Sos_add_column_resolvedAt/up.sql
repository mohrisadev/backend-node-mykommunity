alter table "public"."Sos" add column "resolvedAt" timestamptz
 null;
