alter table "public"."Visitors" add column "visitorCount" numeric
 null;
