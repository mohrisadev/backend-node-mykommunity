alter table "public"."Sos" add column "societyId" uuid
 not null;
