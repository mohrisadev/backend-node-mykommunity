DROP TABLE "public"."Gates";
