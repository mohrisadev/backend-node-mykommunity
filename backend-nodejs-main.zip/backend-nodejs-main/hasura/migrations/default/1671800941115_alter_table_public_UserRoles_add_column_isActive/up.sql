alter table "public"."UserRoles" add column "isActive" boolean
 not null default 'True';
