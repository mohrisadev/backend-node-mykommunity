alter table "public"."LocalServiceProviderLogs" add column "societyId" uuid
 not null;
