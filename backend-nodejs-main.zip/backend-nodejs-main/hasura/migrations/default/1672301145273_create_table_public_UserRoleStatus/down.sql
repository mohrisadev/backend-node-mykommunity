DROP TABLE "public"."UserRoleStatus";
