alter table "public"."LocalServiceProviders" add column "societyId" uuid
 not null;
