alter table "public"."Visitors" add column "isWearingMask" boolean
 null;
