alter table "public"."Notices" drop constraint "Notices_userId_fkey";
