DROP INDEX IF EXISTS "public"."LocalServiceProviderAndRentalUnits_localServiceProviderId";
