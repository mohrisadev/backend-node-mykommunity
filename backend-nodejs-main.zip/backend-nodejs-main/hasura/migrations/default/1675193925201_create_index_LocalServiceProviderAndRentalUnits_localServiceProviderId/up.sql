CREATE  INDEX "LocalServiceProviderAndRentalUnits_localServiceProviderId" on
  "public"."LocalServiceProviderAndRentalUnits" using btree ("localServiceProviderId");
