alter table "public"."BookedAmenityStatus" rename column "amenityId" to "bookedAmenityId";
