alter table "public"."BookedAmenityStatus" rename column "bookedAmenityId" to "amenityId";
