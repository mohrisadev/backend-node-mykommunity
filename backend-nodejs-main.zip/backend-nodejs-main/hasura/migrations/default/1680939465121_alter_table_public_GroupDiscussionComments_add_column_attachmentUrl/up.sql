alter table "public"."GroupDiscussionComments" add column "attachmentUrl" text
 null;
