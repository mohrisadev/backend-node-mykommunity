alter table "public"."BookedAmenity" drop constraint "BookedAmenity_rentalUnitId_fkey";
