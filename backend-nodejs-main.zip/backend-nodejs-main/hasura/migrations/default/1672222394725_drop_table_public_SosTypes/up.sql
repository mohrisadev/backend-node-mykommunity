DROP table "public"."SosTypes";
