DROP TABLE "public"."Vehicles";
