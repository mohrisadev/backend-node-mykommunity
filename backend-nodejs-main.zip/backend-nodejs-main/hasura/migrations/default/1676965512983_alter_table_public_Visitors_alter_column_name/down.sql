alter table "public"."Visitors" alter column "name" set not null;
