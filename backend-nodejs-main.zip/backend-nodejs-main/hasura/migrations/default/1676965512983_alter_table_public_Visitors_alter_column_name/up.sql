alter table "public"."Visitors" alter column "name" drop not null;
