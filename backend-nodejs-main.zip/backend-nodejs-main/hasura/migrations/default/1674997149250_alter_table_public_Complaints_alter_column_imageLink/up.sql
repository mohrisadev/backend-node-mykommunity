alter table "public"."Complaints" rename column "imageLink" to "image";
