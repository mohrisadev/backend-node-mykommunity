alter table "public"."Complaints" rename column "image" to "imageLink";
