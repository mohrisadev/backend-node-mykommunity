alter table "public"."Visitors" add column "vendorName" text
 null;
