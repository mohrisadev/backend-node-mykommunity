DROP TABLE "public"."ComplaintCategories";
