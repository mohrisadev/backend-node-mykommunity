alter table "public"."BookedAmenity" add column "rentalUnitId" uuid
 not null;
