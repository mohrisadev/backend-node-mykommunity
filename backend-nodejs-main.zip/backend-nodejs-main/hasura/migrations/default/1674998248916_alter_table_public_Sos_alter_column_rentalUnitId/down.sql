alter table "public"."Sos" alter column "rentalUnitId" drop not null;
