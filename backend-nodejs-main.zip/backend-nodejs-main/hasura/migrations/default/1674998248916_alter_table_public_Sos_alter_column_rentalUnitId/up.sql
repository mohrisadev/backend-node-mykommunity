alter table "public"."Sos" alter column "rentalUnitId" set not null;
