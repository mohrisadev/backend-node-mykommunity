alter table "public"."Users" add column "password" text
 null;
