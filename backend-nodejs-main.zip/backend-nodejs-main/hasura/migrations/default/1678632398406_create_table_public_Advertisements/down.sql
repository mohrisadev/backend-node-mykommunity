DROP TABLE "public"."Advertisements";
