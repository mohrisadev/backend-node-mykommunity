DROP TABLE "public"."EmergencyContacts";
