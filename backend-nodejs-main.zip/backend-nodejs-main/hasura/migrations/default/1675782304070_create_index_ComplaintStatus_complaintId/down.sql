DROP INDEX IF EXISTS "public"."ComplaintStatus_complaintId";
