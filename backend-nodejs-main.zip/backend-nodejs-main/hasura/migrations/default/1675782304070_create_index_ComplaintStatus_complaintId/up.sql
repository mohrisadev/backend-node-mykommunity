CREATE  INDEX "ComplaintStatus_complaintId" on
  "public"."ComplaintStatus" using btree ("complaintId");
