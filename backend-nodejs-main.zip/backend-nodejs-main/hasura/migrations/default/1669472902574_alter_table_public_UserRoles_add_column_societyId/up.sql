alter table "public"."UserRoles" add column "societyId" uuid
 null;
