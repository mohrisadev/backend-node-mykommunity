alter table "public"."Visitors" add column "imageUrl" text
 null;
