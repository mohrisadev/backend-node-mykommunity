alter table "public"."Societies" alter column "builderName" set not null;
