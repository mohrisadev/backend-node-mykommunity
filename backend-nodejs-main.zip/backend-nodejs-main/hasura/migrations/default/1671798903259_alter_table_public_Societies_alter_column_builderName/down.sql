alter table "public"."Societies" alter column "builderName" drop not null;
