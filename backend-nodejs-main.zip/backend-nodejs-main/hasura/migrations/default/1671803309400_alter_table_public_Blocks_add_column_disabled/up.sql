alter table "public"."Blocks" add column "disabled" boolean
 not null default 'false';
