alter table "public"."GroupDiscussion" rename column "imageUrl" to "fileUrl";
