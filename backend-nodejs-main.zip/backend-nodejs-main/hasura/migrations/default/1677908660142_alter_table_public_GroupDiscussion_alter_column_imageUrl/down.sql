alter table "public"."GroupDiscussion" rename column "fileUrl" to "imageUrl";
