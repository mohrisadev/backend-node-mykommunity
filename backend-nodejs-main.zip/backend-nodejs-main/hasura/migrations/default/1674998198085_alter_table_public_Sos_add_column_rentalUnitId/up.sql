alter table "public"."Sos" add column "rentalUnitId" uuid
 null;
