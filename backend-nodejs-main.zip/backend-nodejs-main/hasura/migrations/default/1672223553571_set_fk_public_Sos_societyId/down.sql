alter table "public"."Sos" drop constraint "Sos_societyId_fkey";
