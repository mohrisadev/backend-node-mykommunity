alter table "public"."BookedAmenityStatus" drop constraint "BookedAmenityStatus_bookedAmenityId_fkey";
