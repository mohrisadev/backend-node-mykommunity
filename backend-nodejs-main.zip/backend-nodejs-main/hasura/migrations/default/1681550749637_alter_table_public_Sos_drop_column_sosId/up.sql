alter table "public"."Sos" drop column "sosId" cascade;
