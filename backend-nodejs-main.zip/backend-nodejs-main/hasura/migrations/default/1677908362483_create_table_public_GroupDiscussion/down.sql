DROP TABLE "public"."GroupDiscussion";
