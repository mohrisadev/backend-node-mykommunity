alter table "public"."Floors" add column "disabled" boolean
 not null default 'false';
