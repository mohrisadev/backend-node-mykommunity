alter table "public"."Users" alter column "email" drop not null;
