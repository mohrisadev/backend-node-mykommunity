alter table "public"."Users" alter column "email" set not null;
