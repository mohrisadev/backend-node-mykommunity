DROP TABLE "public"."BookedAmenity";
