alter table "public"."States" add column "disabled" boolean
 not null default 'false';
