DROP TABLE "public"."LocalServiceProviderLogs";
