DROP TABLE "public"."awfawf";
