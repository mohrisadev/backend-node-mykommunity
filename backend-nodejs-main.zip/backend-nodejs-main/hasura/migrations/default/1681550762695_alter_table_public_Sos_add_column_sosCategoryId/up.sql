alter table "public"."Sos" add column "sosCategoryId" uuid
 not null;
