alter table "public"."Sos" drop column "rentalUnitId" cascade;
