alter table "public"."BookedAmenityStatus" drop constraint "AmenityStatus_amenityId_fkey";
