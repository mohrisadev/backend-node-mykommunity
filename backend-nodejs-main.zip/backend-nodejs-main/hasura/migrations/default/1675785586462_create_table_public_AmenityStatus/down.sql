DROP TABLE "public"."AmenityStatus";
