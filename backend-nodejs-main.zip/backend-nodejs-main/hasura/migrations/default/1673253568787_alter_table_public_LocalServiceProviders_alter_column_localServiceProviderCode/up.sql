alter table "public"."LocalServiceProviders" alter column "localServiceProviderCode" set not null;
