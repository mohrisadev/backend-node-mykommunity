alter table "public"."LocalServiceProviders" alter column "localServiceProviderCode" drop not null;
