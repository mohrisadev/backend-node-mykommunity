alter table "public"."UserRoles" drop column "isActive" cascade;
